import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `
  <h1>Hello {{name}}</h1>
  <recipe-list></recipe-list>
  `,
})
export class AppComponent  { 
	pagetitle: string = "Have some Cake";
}
